import UIKit
// Strings

// 1: isUnique

func isUnique(string : String) -> Bool {
    var characterArray = [Character]()
    for char in string {
        if (characterArray.contains(char)){
            return false
        }
        characterArray.append(char)
    }
    return true
}

func isUnique2(string: String) -> Bool {
    return Set(string).count == string.count
}

isUnique(string: "abc")
isUnique2(string: "abcb")


// 2. isPallindrome


func isPallindrome(string : String) -> Bool {
    let lowercase = string.lowercased();
    return ((lowercase).reversed()) == Array(lowercase)
}

isPallindrome(string: "Rats live on no evil star")


// 3. Same Char String?

func areSameChars(str1 : String, str2: String) -> Bool {
    let setStr = Set(str1)
    for char in str2 {
        if !(setStr.contains(char)) {
            return false
        }
    }
    return true
}

func areSameChars2(str1 : String, str2: String) -> Bool {
    let array1 = Array(str1)
    let array2 = Array(str2)
    
    return array1.sorted() == array2.sorted()
}

areSameChars(str1: "abc", str2: "abca")
areSameChars2(str1: "abc", str2: "abca")


// 4. isStringSubset
extension String {
    func stringContains(_ str : String) -> Bool {
        return (self.uppercased().range(of: str.uppercased())) != nil
    }
}

"Hello world".stringContains("world")


// 5. countChars
func countChars(string: String) {
    var dict = [Character : Int]()
    for char in string {
        if dict[char] !=  nil {
            dict[char]! += 1
        } else {
            dict[char] = 1
        }
    }
    print(dict)
}

countChars(string: "The rain in Spain")
countChars(string:"Mississippi")

// 6. Remove duplicates

func removeDuplicates (string: String) -> String {
    var characterArray = [Character]()
    for char in string {
        if !characterArray.contains(char) {
            characterArray.append(char)
        }
    }
    return String(characterArray)
}

removeDuplicates(string: "Mississippi")

// 7. CondenseWhiteSpaces

func condenseWhitespaces (string: String) -> String {
    let comp = string.components(separatedBy: .whitespacesAndNewlines)
    return comp.filter{!$0.isEmpty}.joined(separator:  " ")
    
}

condenseWhitespaces(string: "Hello   Wit   kim")

// 8. String Rotation

func isStringRotated(string: String, stringRotation: String) -> Bool {
    guard string.count == stringRotation.count else {return false}
    var newStr = string + string
    return newStr.range(of: stringRotation) != nil
}

isStringRotated(string: "abc", stringRotation: "a")

// 9. Panagrams

func isPanagram(var string: String) -> Bool {
    let set = Set(string.lowercased()) // duplicate removed, all lowercased
    let letters = set.filter {$0 >= "a" && $0 <= "z"} // only a-z
    return letters.count == 26
}

print(isPanagram(var: "The quick brown fox jumps over the lazy dog"))

// 10. Vowels & Consonants

func isVowelConsonant(_ str : String) -> (Int,Int) {
    var vowelCount = 0
    var consonantCount = 0
    
    let set = str.lowercased()
    let letters = set.filter{$0 >= "a" && $0 <= "z"}
    
    for i in letters {
        switch i {
        case "a","e","i","o","u":
            vowelCount += 1
        default:
            consonantCount += 1
        }
    }
    return (vowelCount,consonantCount)
}

print(isVowelConsonant("Swift Coding Challenges"))

// 11. ThreeDiffLetters

func isThreeDiff (str1: String, str2: String) -> Bool {
    guard (str1.count != str2.count) else { return false }
    var arStr1 = Array(str1)
    var arStr2 = Array(str2)
    var isDiffCounter = 0
    
    for (index, char) in arStr1.enumerated() {
        if(arStr2[index] != arStr1[index]) {
            isDiffCounter += 1
            if (isDiffCounter > 3) { return false}
        }
    }
    return true
}

isThreeDiff(str1: "Clamp", str2: "Grams")

// 12. findLongestPrefix

func findLongestPrefix(strings : String) -> String {
    var stringArray = strings.components(separatedBy: .whitespacesAndNewlines)
    guard let first = stringArray.first else { return ""}
    
    var longestPrefix = ""
    var currentPrefix = ""
    
    for char in first {
        currentPrefix.append(char) // s
        for word in stringArray {
            if !word.hasPrefix(currentPrefix) {
                return longestPrefix
            }
        }
        longestPrefix = currentPrefix
    }
    
    return longestPrefix
}

print(findLongestPrefix(strings: "swift switch swill swim"))


// 13. Run Length Encoding

func runLengthEncoding(str : String) -> String {
    var strArray = Array(str)
    var counter = 0
    var answer = ""
    
    for (index,char) in strArray.enumerated() {
        if ((index+1) < strArray.count) {
            if (strArray[index] != strArray[index + 1]) {
                counter += 1
                answer += String(char)
                answer += String(counter)
                counter = 0
            } else {
                counter += 1
            }
        } else {
            counter += 1
            answer += String(char)
            answer += String(counter)
            counter = 0
        }
    }
    return answer
}

runLengthEncoding(str: "aaAAaa")


// 14. String Permutation

func stringPermutation(str: String, currString: String ) {
    var strArray = Array(str)
    var count = str.count
    if(count == 0) {print(currString)}
    else {
        for i in 0..<count {
            let left = String(strArray[0..<i])
            let right = String(strArray[i+1..<count])
            stringPermutation(str: left+right, currString: currString + String(strArray[i]))
        }
        
    }
}

//stringPermutation(str: "wombat", currString: "")

// 15. reverseString
func reverseString(str: String) -> String {
    var parts = str.components(separatedBy: .whitespacesAndNewlines)
    var string = parts.map{String($0.reversed())}
    return string.joined(separator: " ")
}

reverseString(str: "abc abie")

// 37 : Count The numbers

extension Collection where Iterator.Element ==  Int {
    
    func countTheNumbers(count integer:String) -> Int {
        var count = 0
        for x in self {
            let y = String(x)
            for char in y {
                if String(char) == integer {
                    count += 1
                }
            }
            
        }
        return count
    }
   
}

[5, 15, 55, 515].countTheNumbers(count: "5")

// 38. Find N Smallest

extension Collection where Iterator.Element : Comparable {
    func findNSmallest(count count1: Int) -> [Iterator.Element] {
        var sorted = self.sorted()
        return Array(sorted.prefix(count1))
    }
    
}

[1, 2, 3, 4].findNSmallest(count: 3)

// 39. Sort a string array by length

extension Collection where Iterator.Element == String {
    func sortArray() -> [String] {
        return self.sorted {$0 > $1}
    }
}


["a", "abc", "ab"].sortArray()


// 40. Missing Numbers

func missingNumber(_ testArray:[Int]) -> [Int] {
    var array = Array(1...100)
    var answerArray = [Int]()
    let inpurSet = Set(testArray)
    for value in array {
        if !inpurSet.contains(value) {
            answerArray.append(value)
        }
    }
    return answerArray
}

var testArray = Array(1...100)
testArray.remove(at: 25)
testArray.remove(at: 20)
testArray.remove(at: 6)
missingNumber(testArray)
